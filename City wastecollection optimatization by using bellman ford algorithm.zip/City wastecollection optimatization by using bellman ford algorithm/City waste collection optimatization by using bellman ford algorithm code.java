import java.util.*;

class Main {
    
    // Data structure to represent the graph
    static class Graph {
        int V; // Number of vertices
        LinkedList<Edge> adjList[];

        // Constructor
        Graph(int V) {
            this.V = V;
            adjList = new LinkedList[V];
            for (int i = 0; i < V; ++i)
                adjList[i] = new LinkedList<>();
        }

        // Add edge to the graph
        void addEdge(int u, int v, int weight) {
            adjList[u].add(new Edge(v, weight));
        }

        // Bellman-Ford algorithm to find shortest paths
        void bellmanFord(int src) {
            int dist[] = new int[V];
            Arrays.fill(dist, Integer.MAX_VALUE);
            dist[src] = 0;

            // Relax edges |V| - 1 times
            for (int i = 1; i < V; ++i) {
                for (int u = 0; u < V; u++) {
                    for (Edge edge : adjList[u]) {
                        if (dist[u] != Integer.MAX_VALUE && dist[u] + edge.weight < dist[edge.dest]) {
                            dist[edge.dest] = dist[u] + edge.weight;
                        }
                    }
                }
            }

            // Check for negative-weight cycles
            for (int u = 0; u < V; u++) {
                for (Edge edge : adjList[u]) {
                    if (dist[u] != Integer.MAX_VALUE && dist[u] + edge.weight < dist[edge.dest]) {
                        System.out.println("Graph contains negative weight cycle");
                        return;
                    }
                }
            }

            // Print the shortest distance
            printSolution(dist);
        }

        // Print the shortest distances
        void printSolution(int dist[]) {
            System.out.println("Shortest distances from the source:");
            for (int i = 0; i < V; ++i) {
                if (dist[i] == Integer.MAX_VALUE) {
                    System.out.println("Node " + i + " : Unreachable");
                } else {
                    System.out.println("Node " + i + " : " + dist[i]);
                }
            }
        }
    }

    // Edge class
    static class Edge {
        int dest, weight;

        Edge(int dest, int weight) {
            this.dest = dest;
            this.weight = weight;
        }
    }

    // Main function
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Read number of vertices (collection points)
        System.out.print("Enter the number of collection points: ");
        int V = sc.nextInt();
        
        // Create the graph
        Graph g = new Graph(V);

        // Read the number of edges (roads between points)
        System.out.print("Enter the number of roads (edges): ");
        int E = sc.nextInt();

        // Read each edge (road)
        System.out.println("Enter the roads in the format 'u v weight' (where u and v are node indices and weight is the road's cost or distance): ");
        for (int i = 0; i < E; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            int weight = sc.nextInt();
            g.addEdge(u, v, weight);
        }
        
        // Read the starting point (waste collection hub)
        System.out.print("Enter the starting node (waste collection hub): ");
        int src = sc.nextInt();
        
        // Call Bellman-Ford starting from the source node
        g.bellmanFord(src);
        
    
    }
}
